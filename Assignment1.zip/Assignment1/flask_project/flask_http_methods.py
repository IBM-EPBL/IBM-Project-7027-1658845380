from flask import Flask, jsonify, request
app = Flask(__name__) 

students = [{'name' : 'Abisankar'}, {'name' : 'Manohar'}, {'name' : 'Kavinkumar'},{'name':'Prasanth'}]

@app.route('/', methods=['GET'])
def test():
	return jsonify({'message' : 'Sample Program for flask HTTP methods (GET,POST,PUT,DELETE) have been successfully executed'})

@app.route('/students', methods=['GET'])
def returnAll():
	return jsonify({'students' : students})

@app.route('/students/<string:name>', methods=['GET'])
def returnOne(name):
	stud = [student for student in students if student['name'] == name]
	return jsonify({'students' : stud[0]})

@app.route('/students', methods=['POST'])
def addOne():
	student = {'name' : request.json['name']}

	students.append(student)
	return jsonify({'students' : students})

@app.route('/students/<string:name>', methods=['PUT'])
def editOne(name):
	stud = [student for student in students if student['name'] == name]
	stud[0]['name'] = request.json['name']
	return jsonify({'students' : stud[0]})

@app.route('/students/<string:name>', methods=['DELETE'])
def removeOne(name):
	stud = [student for student in students if student['name'] == name]
	students.remove(stud[0])
	return jsonify({'students' : students})

if __name__ == '__main__':
	app.run(debug=True, port=8080)